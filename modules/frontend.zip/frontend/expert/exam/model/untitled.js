const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();



const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();


const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();


const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();



const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();


const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
















const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();



const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();


const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();




const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();



const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();


const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
















const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();



const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();


const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();
const { ObjectId } = require("mongodb");
const stripe = require("stripe")('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

function Plans(req, res) {

	/** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
		const plan = await stripe.plans.create({
		  	amount: 16600,
		  	currency: 'usd',
		  	interval: 'month',
		  	product: 'prod_JfVRWlxvKaDWgH',
		});			
	
		const subscription = await stripe.subscriptions.create({
		  	customer: 'cus_4QEipX9Dj5Om1P',
		  	items: [{price: 'price_1J2AQH2eZvKYlo2CxzXz8JBE'}],
		});

		console.log(subscription, "subscription")
  	} //End planSubscription
}
module.exports = new Plans();










































