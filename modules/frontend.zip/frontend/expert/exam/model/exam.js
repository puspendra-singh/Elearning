const { ObjectId } = require("mongodb");
const asyncForEachOf = require("async/forEachOf");
function Exam(req, res) {
  /** Function is used to get exam questions **/
  this.examQuestions = (req, res, next) => {
    let languageId = (req.body.language_id) ? req.body.language_id : DEFAULT_LANGUAGE_MONGO_ID;
    let userId = (req.body.user_id) ? req.body.user_id : '';

    /** Is valid request */
    if (!userId) {
      return res.send({
        status: API_STATUS_ERROR,
        message: res.__("front.user.invalid_request"),
        result: {},
        error: [],
      });
    }

    /** Get questions list **/
    const collection = db.collection("examinations");
    collection.aggregate([
      {
        $match: {
          user_id      : ObjectId(userId),
        }
      },
      { $unwind: '$exam_questions' },
      {
        $lookup: {
          from: "questions",
          let: { questionId: "$exam_questions._id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$_id", "$$questionId"] },
                  ],
                },
              }
            },
            {
              $lookup: {
                from: "categories",
                let: { categoryId: "$category" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          { $eq: ["$_id", "$$categoryId"] },
                        ],
                      },
                    }
                  },
                  { $project: { name: 1 } },
                ],
                as: "categoryIdDetail",
              }
            },
            {
              $project: {
                question_type: 1, _id: 1,
                category_name: { '$arrayElemAt': ["$categoryIdDetail.name", 0] },
                qns_data: "$qns_data." + languageId + ""
              }
            },
            {
              $addFields: {
                'qns_data.question_id': "$_id",
                'qns_data.question_type': "$question_type",
                'qns_data.category_name': "$category_name"
              }
            }
          ],
          as: "questionDetail",
        }
      },
      {
        $group: {
          _id: '$_id',
          user_id: { $first: "$user_id" },
          is_passed: { $first: "$is_passed" },
          is_answered: { $first: "$is_answered" },
          is_completed: { $first: "$is_completed" },
          exam_duration: { $first: "$time_duration" },
          qns_data: { $push: { '$arrayElemAt': ["$questionDetail.qns_data", 0] } }
        }
      }
    ]).toArray((err, result) => {

      /** return success */
      return res.send({
        status: API_STATUS_SUCCESS,
        message: '',
        result: (result && result.length > NOT) ? result[0] : {},
        error: '',
      });
    })
  }// End examQuestions


  /** Function is used to submit exam **/
  this.submitExam = (req, res, next) => {
    let userId = (req.body.user_id) ? req.body.user_id : '';
    let examId = (req.body.exam_id) ? req.body.exam_id : '';
    let examData = (req.body.exam_data) ? req.body.exam_data : [];

    /** Is valid request */
    if (!userId || !examId || examData && examData.length == NOT) {
      return res.send({
        status: API_STATUS_ERROR,
        message: res.__("front.user.invalid_request"),
        result: {},
        error: [],
      });
    }

    const collection = db.collection("examinations");
    asyncForEachOf(examData, async (row, index, callback) => {
      collection.findOneAndUpdate(
        {
          user_id: ObjectId(userId),
          _id: ObjectId(examId),
          exam_questions: { $elemMatch: { _id: ObjectId(row.question_id) } }
        },
        {
          $set: {
            "exam_questions.$.user_answer": row.user_answer,
            "exam_questions.$.is_answer": row.is_answer,
            "exam_questions.$.modified": getUtcDate()
          }
        }, (err, result) => { });
      callback(null);
    }, err => {
      collection.findOneAndUpdate(
        {
          user_id: ObjectId(userId),
          _id: ObjectId(examId)
        },
        {
          $set: {
            "is_answered": ACTIVE,
            "submit_date": getUtcDate()
          }
        }, (err, result) => {
          if (err) return next(err)

          /** return success */
          return res.send({
            status: API_STATUS_SUCCESS,
            message: res.__("front.user.exam_has_been_submitted_successfully"),
            result: result,
            error: '',
          });
        }
      );
    });
  }// End submitExam
}
module.exports = new Exam();
