/** Model file path for current plugin **/
const modelPath     =	__dirname+"/model/exam";
const exam	        =   require(modelPath);

/** Routing is used to get exam questions **/
routes.post(API_URL+"exam_questions",(req,res,next)=>{
    exam.examQuestions(req,res,next);
});

/** Routing is used to submit exam questions **/
routes.post(API_URL+"submit_exam",(req,res,next)=>{
    exam.submitExam(req,res,next);
});
