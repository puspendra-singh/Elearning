/** Model file path for current plugin **/
const modelPath     =	__dirname+"/model/user";
const user	        =   require(modelPath);

/** Routing is used to user signup **/
routes.post(API_URL+"signup",(req,res,next)=>{
    user.signup(req,res,next);
});

/** Routing is used to phone verificaton **/
routes.post(API_URL+"phone_verification",(req,res,next)=>{
    user.phoneVerification(req,res,next);
});

/** Routing is used to resend otp **/
routes.post(API_URL+"resend_otp",(req,res,next)=>{
    user.resendOtp(req,res,next);
});

/** Routing is used to email verificaton **/
routes.get(API_URL+"email_verification/:validate_string/:role_id",(req,res,next)=>{
    user.emailVerification(req,res,next);
});

/** Routing is used to new email verificaton **/
routes.get(API_URL+"new_email_verification/:validate_string/:role_id",(req,res,next)=>{
    user.newEmailVerification(req,res,next);
});

/** Routing is used to resend email **/
routes.post(API_URL+"resend_email",(req,res,next)=>{
    user.resendEmail(req,res,next);
});

/** Routing is used to forgot password **/
routes.post(API_URL+"forgot_password",(req,res,next)=>{
    user.forgotPassword(req,res,next);
});

/** Routing is used to reset_password **/
routes.post(API_URL+"reset_password",(req,res,next)=>{
    user.resetPassword(req,res,next);
});

/** Routing is used to get user login **/
routes.post(API_URL+"login",(req,res,next)=>{
    user.login(req,res,next);
});

/** Routing is used to get user data **/
routes.post(API_URL+"user_data",(req,res,next)=>{
    user.getUserDetail(req,res,next);
});

/** Routing is used to user profile setup**/
routes.post(API_URL+"profile_setup",(req,res,next)=>{
    user.profileSetup(req,res,next);
});

/** Routing is used to edit user data **/
routes.post(API_URL+"edit_profile",(req,res,next)=>{
    user.updateProfile(req,res,next);
});

/** Routing is used to delete user data **/
routes.post(API_URL+"delete_profile_data",(req,res,next)=>{
    user.deleteProfileData(req,res,next);
});

