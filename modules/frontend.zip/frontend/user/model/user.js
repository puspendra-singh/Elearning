const bcrypt = require("bcryptjs");
const { ObjectId } = require("mongodb");
const asyncForEachOf    = require("async/forEachOf");


function User(req, res) {

  /** Function is used to user login **/
  this.login = async(req, res)=> {
    req.body          = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let email         = (req.body.email) ? req.body.email : '';
    let password      = (req.body.password) ? req.body.password : '';
    let languageId    = (req.body.language_id) ? req.body.language_id : '';

    /** Check body */
    req.checkBody({	
      "email" :{
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_enter_your_email_or_mobile")
      },
      "password":{
        isLength		:{
          options    : {min : PASSWORD_MIN_LENGTH , max : PASSWORD_MAX_LENGTH},
          errorMessage:res.__("admin.user.password_should_be_6_characters_long")
        },
        matches	 : {
          options    	: PASSWORD_ALPHANUMERIC_REGEX,
          errorMessage:res.__("admin.user.password.it_should_be_alphanumeric")
        },
        notEmpty		:true,
        errorMessage	:res.__("admin.user.please_enter_password")
      },
    });

    let errors  = parseValidationFront(req.validationErrors());
    errors      = (errors && Object.keys(errors).length>0) ? errors :  {};

    if(Object.keys(errors).length == 0){
      let searchCondition       = { is_deleted : NOT_DELETED};
      searchCondition['email']  = { $regex: new RegExp("^" + email, "i") };

      /** get user */
      let collection = db.collection('users');
      collection.findOne(searchCondition, async (err, result)=>{
        let userDetail = (result && Object.keys(result).length > NOT) ? result :{};
        if(err) return next(err);

        if(Object.keys(userDetail).length == NOT){
          return res.send({
            status		:	API_STATUS_ERROR,
            message		:	res.__("front.user.login.invalid_username_password"),
            result    : {},
            error		  :	[],
          });
        }

        /** Compare password */
        const bcrypt = require("bcryptjs");
        bcrypt.compare(password, result.password, async (err, isMatch) => {
          if(result && Object.keys(result).length > NOT && isMatch){
            let response= {
              status          : API_STATUS_SUCCESS,
              message         : res.__("front.user.login.successfully_login"),
              result          : {},
              token           : '',
              error		        :	[],
            };

            if(result.is_active == DEACTIVE) {
              response['status']		=	API_STATUS_ERROR;
              response['message']   = res.__("front.user.login.account_deactivate_contact_to_admin");
            }else if(result.email_verified == NOT_VERIFIED){
                response['result']      = {email_validate_string : result.email_validate_string}
                response['status']	    =	API_STATUS_ERROR;
                response['message']     = res.__("front.user.login.email_not_verified");
            }else if(result.phone_verified == NOT_VERIFIED) {
                response['result']    = {phone_validate_string : result.phone_validate_string}
                response['status']		=	API_STATUS_ERROR; 
                response['message']   = res.__("front.user.login.mobile_not_verified")
            }else{
              if(Object.keys(result).length == NOT){
                return res.send({
                  status		      :	API_STATUS_ERROR,
                  message		      :	res.__("front.user.login.invalid_username_password"),
                  result          : {},
                  error		        :	[],
                })
              } 
              /*** End user detail */

              let data      = {slug : result.slug, user_key : result._id, email : result.email, mobile: result.mobile, role_id : result.role_id}; 
              let token     = generateJWT(data);
              response['token']   = token;
              response['result']  = {slug : result.slug, user_id : result._id, email : result.email, mobile: result.mobile, role_id : result.role_id};;
            }
            return res.send(response);
          }else{
            return res.send({
              status		:	API_STATUS_ERROR,
              message		:	res.__("front.user.login.invalid_username_password"),
              result    : {},
              error		  :	[],
            });
          }
        }) 
      })
    }else{
      return res.send({
        status		:	API_STATUS_ERROR,
        message		:	'',
        result    : {},
        error		  :	errors,
      });
    }
  }


  /** Function is used to user signup **/
  this.signup = async (req, res, next)=> {
    req.body      = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);

    /*** Common validation for all types of user */
    req.checkBody({	
      "full_name":{
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_enter_full_name")
      },
      "email":{
        notEmpty		:true,
        isEmail			:{
          errorMessage:res.__("front.user.please_enter_a_valid_email")
        },
        errorMessage	:res.__("front.user.please_enter_an_email"),
      },
      "phone":{
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_enter_mobile"),
      },
      "gender":{
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_enter_full_name")
      },
      "country_name":{
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_select_country")
      },
      "city_name":{
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_select_city")
      },
      "nationality":{
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_select_nationality")
      },
      "currency":{
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_select_currency")
      },
      "date_of_birth":{
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_select_date_of_birth")
      },
      "password":{
        isLength		:{
          options    : {min : PASSWORD_MIN_LENGTH , max : PASSWORD_MAX_LENGTH},
          errorMessage:res.__("front.user.password_should_be_6_characters_long")
        },
        matches	 : {
          options    	: PASSWORD_ALPHANUMERIC_REGEX,
          errorMessage:res.__("front.user.password.it_should_be_alphanumeric")
        },
        notEmpty		:true,
        errorMessage	:res.__("front.user.please_enter_password")
      },
      "confirm_password":{ 
        isLength		:{
          options    : {min :PASSWORD_MIN_LENGTH,  max : PASSWORD_MAX_LENGTH},
          errorMessage:res.__("front.user.password.it_should_be_6_characters_long")
        },
        matches	 : {
          options    	: PASSWORD_ALPHANUMERIC_REGEX,
          errorMessage:res.__("front.user.password.it_should_be_alphanumeric")
        },
        notEmpty : true,
        errorMessage	:res.__("front.user.please_enter_confirm_password")	
      },
    });
    
    let roleId                 = (req.body.role_id)            ? Number(req.body.role_id) : NOT;
    let email 					       = (req.body.email)						   ?	req.body.email:'';
    let gender 					       = (req.body.gender)						 ?	req.body.gender:'';
    let countryName 					 = (req.body.country_name)		   ?	req.body.country_name:'';
    let cityName 					     = (req.body.city_name)					 ?	req.body.city_name:'';
    let dateOfBirth 					 = (req.body.date_of_birth)			 ?	req.body.date_of_birth:'';
    let nationality 					 = (req.body.nationality)			   ?	req.body.nationality:'';
    let currency 					     = (req.body.currency)			     ?	req.body.currency:'';
    let phone 					       = (req.body.phone)						   ?	req.body.phone:{};
    let fullName				       = (req.body.full_name)			     ?	req.body.full_name:'';
    let password 				       = (req.body.password)					 ?	req.body.password:'';
    let confirmPassword 		   = (req.body.confirm_password)   ?	req.body.confirm_password:'';
    let encryptPassword 		   = bcrypt.hashSync(password, BCRYPT_PASSWORD_SALT_ROUNDS);

    /** Match password with confirm password */
    if (password && confirmPassword) {
      req.checkBody("confirm_password", "admin.user.password_does_not_matched").equals(req.body.password);
    }

    let errors  = parseValidationFront(req.validationErrors());
    errors      = (errors && Object.keys(errors).length>0) ? errors :  {};

    /** user email unique options */
    if(email){
      let emailUniqueOptions = {
        table_name  : "users",
        field_value : email,
        field_name  : 'email'
      };
  
      let isEmailUnique  = await checkUniqueValue(emailUniqueOptions);
      if(isEmailUnique && isEmailUnique.status == STATUS_ERROR){
        errors['email']= res.__("front.user.email_is_already_in_use_please_try_something_different")
      }
    }
    

    /** user mobile unique options */
    if(phone){
      let mobileUniqueOptions = {
        table_name  : "users",
        field_value : phone,
        field_name  : 'phone'
      };
  
      let isMobileUnique  = await checkUniqueValue(mobileUniqueOptions);
      if(isMobileUnique && isMobileUnique.status == STATUS_ERROR){
        errors['phone']= res.__("front.user.phone_is_already_in_use_please_try_something_different")
      }
    }
    
    if(errors && Object.keys(errors).length == NOT){
      /** Slug options */
      let slugOptions = {
        table_name  : "users",
        title       : fullName,
        slug_field  : 'full_name'
      };

      const stripe = require('stripe')(res.locals.settings["Stripe.key"]);
      const customer = await stripe.customers.create({
        email : email,
        name  : fullName
      });

      /** get slug form database */
      getDatabaseSlug(slugOptions).then(responseSlug=>{
        let slug  = (responseSlug.title) ? responseSlug.title  : '';

        /** get string */
        getRandomString(VALIDATE_STRING_ROUND).then(responseString=>{
          let phoneValidateString   = (responseString.result) ? responseString.result : '';
          let insertData = {
            full_name					        :	fullName,
            slug                      : slug,
            email						          :	email,
            phone						          :	phone,
            gender						        :	gender,
            country_name						  :	ObjectId(countryName),
            date_of_birth						  :	newDate(dateOfBirth, GRAPH_DATE_FORMAT),
            nationality						    :	ObjectId(nationality),
            currency						      :	currency,
            city_name						      :	ObjectId(cityName),
            password					        :	encryptPassword,
            role_id						        :	Number(roleId),
            email_verified				    :	NOT_VERIFIED,
            phone_verified				    :	NOT_VERIFIED,
            phone_validate_string   	: phoneValidateString,
            otp                       : Number(1234),
            is_notification_on        : ACTIVE,
            is_email_on               : ACTIVE,
            is_active					        :	ACTIVE,
            is_approved               : DEACTIVE,
            is_profile_step           : DEACTIVE,
            is_profile_updated        : DEACTIVE,
            is_deleted					      :	NOT_DELETED,
            created						        :	new Date(),
            email_link_expired				:	new Date(),
          };
          if(roleId == STUDENT_ROLE_ID) insertData['customer'] = (customer.id) ? customer.id : ''
          signupUser(req,res,insertData)
        }).catch(next);
      }).catch(next);
    }else{
      res.send({
        status	:	API_STATUS_ERROR,
        error		:	errors,
        result  : '',
        message : ''
      });
    }
  }


  /** Function is used to signup user */
	signupUser    = async (req,res,insertData)=>{
		const users	=	db.collection('users');
		users.insertOne(insertData,async (error,result)=>{
      if(error) return next();

      /***Send SMS */
        // let phoneOptions = {
        //   mobile_number : (string) ? userResult.new_mobile : mobile,
        //   sms_template  : "OTP for mobile verification "+ mobileValidateOTP
        // };
        // await sendSMS(req,res,phoneOptions);

      /*** return success */ 
			return res.send({
        status		:	API_STATUS_SUCCESS,
        message		:	res.__("front.user.you_have_successfully_registered_on_accounting_world"),
        result    : {validate_string : insertData.phone_validate_string},
        error		  :	{},
      });
		})
  };// End signupUser
  

  /** Function is used to verify mobile **/
  this.phoneVerification = async (req, res, next)=> {
    req.body            = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let validateOtp     = (req.body.validate_otp)     ? req.body.validate_otp : '';
    let validateString  = (req.body.validate_string)  ? req.body.validate_string : '';
    let roleId          = (req.body.role_id)          ? Number(req.body.role_id) : NOT;

    /*** Invalid request */
    if(!validateOtp || !validateString) return res.send({
      status		:	API_STATUS_ERROR,
      message		:	res.__("front.user.invalid_request"),
      result    : {},
      error		  :	[],
    });

    /** search condition */
    let conditionSearch  = {is_deleted  : NOT_DELETED};
    conditionSearch['otp'] = Number(validateOtp);
    conditionSearch['phone_validate_string']  = validateString;

    /** update condition */
    let conditionUpdate = {};
    conditionUpdate['otp'] = null;
    conditionUpdate['phone_validate_string']  = null;
    conditionUpdate['phone_verified'] = VERIFIED;

    /*** get random string */
    await getRandomString(VALIDATE_STRING_ROUND).then(responseString=>{
      let emailValidateString   = (responseString.result) ? responseString.result : '';
      conditionUpdate['email_validate_string'] = emailValidateString;

      let collection = db.collection('users');
      collection.findOneAndUpdate(conditionSearch,{$set:conditionUpdate},{"projection": {full_name:1, email:1}}, async (err, result)=>{
        if(!err && result && result.lastErrorObject.updatedExisting  == true){
            let userRole = (roleId == EXPERT_ROLE_ID) ? EXPERT_ROLE_NAME : STUDENT_ROLE_NAME;

            /***Send mail */
            let validateURL  = WEBSITE_API_URL+'/email_verification/'+emailValidateString+'/'+userRole;
            let emailOptions = {
              action        : 'registration',
              to            : result.value.email,
              rep_array     : [result.value.full_name, validateURL, validateURL]
            };
            sendEmail(req, res,emailOptions);

            /*** return success */
            return res.send({
              status		:	API_STATUS_SUCCESS,
              message		:	res.__("front.user.mobile_has_been_verified"),
              result    : {validate_string : emailValidateString},
              error		  :	[], 
            });
          
        }else{

          /*** return error */
          if(result && result.lastErrorObject.updatedExisting  == false){
            return res.send({
              status		:	API_STATUS_ERROR,
              message		:	res.__("front.user.mobile_otp_has_been_expired_invalid_otp"),
              result    : {},
              error		  :	[], 
            });
          }
        }
      })
    }).catch(next)
  };

  /** Function is used to resend otp **/
  this.resendOtp = async(req, res, next)=> {
    req.body      = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let string    = (req.body.validate_string) ? req.body.validate_string : '';

    /** Invalid Request */
    if(!string) return res.send({
      status		:	API_STATUS_ERROR,
      message		:	res.__("front.user.invalid_request"),
      result    : {},
      error		  :	[],
    })

    /*** Resend otp */
    let mobileValidateOTP = 1234 //getRandomOTP();

    /** search condition */
    let conditionSearch = { is_deleted  : NOT_DELETED};         
    conditionSearch['phone_validate_string'] = string;

    /** update condition */
    let conditionUpdate = {};
    conditionUpdate['otp']  = Number(mobileValidateOTP);
    //conditionUpdate['phone_validate_string'] = null;
    conditionUpdate['phone_link_expired']   = new Date();

    let collection = db.collection('users');
    collection.findOneAndUpdate(conditionSearch,{$set:conditionUpdate},{"projection": {full_name:1, email:1}}, async (err, result)=>{
      if(!err && result && result.lastErrorObject.updatedExisting  == true){

        /***Send SMS */
        // let phoneOptions = {
        //   mobile_number : (string) ? userResult.new_mobile : mobile,
        //   sms_template  : "OTP for mobile verification "+ mobileValidateOTP
        // };
        // await sendSMS(req,res,phoneOptions);

        /*** return success */
        return res.send({
          status		:	API_STATUS_SUCCESS,
          message		:	res.__("front.user.otp_has_been_sent_on_your_registered_mobile_for_verification"),
          result    : {},
          error		  :	[],
        });
      }else{
        /*** return error */
        return res.send({
          status		:	API_STATUS_ERROR,
          message		:	res.__("front.user.mobile_does_not_exist_in_our_database"),
          result    : {},
          error		  :	[],
        });
      }
    });  
  }


  /** Function is used to resend email **/
  this.resendEmail = async(req, res, next)=> { 
    let string    = (req.body.validate_string) ? req.body.validate_string : '';
    let roleId    = (req.body.role_id) ? req.body.role_id : NOT;
    let type      = (req.body.type) ? req.body.type : NOT;

    /** Invalid Request */
    if(!string) return res.send({  
      status		:	API_STATUS_ERROR,
      message		:	res.__("front.user.invalid_request"),
      result    : {},
      error		  :	[],
    })

    /*** Get random string */
    await getRandomString(VALIDATE_STRING_ROUND).then(responseString=>{
      let validateString   = (responseString.result) ? responseString.result : '';

      /** search condition */
      let conditionSearch = { is_deleted  : NOT_DELETED}; 
      if(type == 'signup'){
        conditionSearch['email_validate_string'] = string;
      }       
      if(type == 'password'){
        conditionSearch['validate_string'] = string;
      }  

      /** update condition */
      let conditionUpdate = {};
      if(type == 'signup'){
        conditionUpdate['email_validate_string']  = validateString;
        conditionUpdate['email_link_expired']     = new Date();
      }
      if(type == 'password'){
        conditionUpdate['validate_string']  = validateString;
        conditionUpdate['link_expired']     = new Date();
      }

      let collection = db.collection('users');
      collection.findOneAndUpdate(conditionSearch,{$set:conditionUpdate},{"projection": {full_name:1, email:1}}, (err, result)=>{
        if(!err && result && result.lastErrorObject.updatedExisting  == true){
            let userRole      = (roleId == EXPERT_ROLE_ID) ? EXPERT_ROLE_NAME : '';
            let emailAction   = (type == 'signup') ? 'email_verification' : 'user/reset-password';
            let validateURL   = '';
            if(type == 'signup') validateURL = WEBSITE_API_URL+'/'+emailAction+'/'+validateString+'/'+userRole;
            if(type == 'password') validateURL = WEBSITE_FRONT_URL+'/'+emailAction+'?validate_string='+validateString;
            
            /***Send mail */
            let emailOptions = {
              action        : (type == 'signup') ? 'registration' : 'forgot_password',
              to            : result.value.email,
              rep_array     : [result.value.full_name, validateURL, validateURL]
            };
            sendEmail(req, res,emailOptions);

            /*** return success */
            return res.send({
              status		:	API_STATUS_SUCCESS,
              message		:	res.__("front.user.link_has_been_sent_on_your_registered_email"),
              result    : {},
              error		  :	[],
            });
        }else{
          /*** return error */
          return res.send({
            status		:	API_STATUS_ERROR,
            message		:	res.__("front.user.email_does_not_exist_in_our_database"),
            result    : {},
            error		  :	[],
          });
        }
      });
    }).catch(next); 
  }

  /** Function is used to verify email **/
  this.emailVerification = (req, res, next)=> {
    let validateString   = (req.params.validate_string)  ? req.params.validate_string : '';
    let roleId           = (req.params.role_id)  ? req.params.role_id : '';
    let userRole         = (roleId == EXPERT_ROLE_NAME) ? EXPERT_ROLE_NAME : STUDENT_ROLE_NAME;

    /*** Invalid request */
    if(!validateString || !userRole) {
      return res.redirect(WEBSITE_FRONT_URL+'/user/'+userRole+'/email?status=error&&message=invalid-request')
    }

    /** search condition */
    let conditionSearch = {};
    conditionSearch['email_validate_string'] = validateString;

    /** update condition */
    let conditionUpdate = {};
    conditionUpdate['email_validate_string']  = null;
    conditionUpdate['email_verified']         = VERIFIED;

    let collection = db.collection('users');
    collection.findOneAndUpdate(conditionSearch,{$set:conditionUpdate},{"projection": {full_name:1, email:1}},(err, result)=>{
      if(!err && result && result.lastErrorObject.updatedExisting  == true){
        return res.redirect(WEBSITE_FRONT_URL+'/user/'+userRole+'/email?status=success&&message=email-verified')
      }else{
        return res.redirect(WEBSITE_FRONT_URL+'/user/'+userRole+'/email?status=error&&message=link-expired')
      }
    });
  };

  
  /** Function is used to verify email **/
  this.newEmailVerification = (req, res, next)=> {
    let validateString   = (req.params.validate_string)  ? req.params.validate_string : '';
    let roleId           = (req.params.role_id)  ? req.params.role_id : '';
    let userRole         = (roleId == EXPERT_ROLE_NAME) ? EXPERT_ROLE_NAME : STUDENT_ROLE_NAME;

    /*** Invalid request */
    if(!validateString || !userRole) {
      return res.redirect(WEBSITE_FRONT_URL+'/user/'+userRole+'/email?status=error&&message=invalid-request')
    }

    /** search condition */
    let conditionSearch = {};
    conditionSearch['email_validate_string'] = validateString;

    /** update condition */
    let conditionUpdate = {};
    //conditionUpdate['email_validate_string']  = null;
    conditionUpdate['email_verified']  = VERIFIED;

    let collection = db.collection('users');
    collection.findOneAndUpdate(conditionSearch,{$set:conditionUpdate},{"projection": {full_name:1, email:1}},(err, result)=>{
      if(!err && result && result.lastErrorObject.updatedExisting  == true){
        conditionUpdate['email']         = result.new_email;
        collection.findOneAndUpdate(conditionSearch,{$set:conditionUpdate},(err, result)=>{})
        return res.redirect(WEBSITE_FRONT_URL+'/'+userRole+'/email?status=success&&message=email-verified')
      }else{
        return res.redirect(WEBSITE_FRONT_URL+'/'+userRole+'/email?status=error&&message=link-expired')
      }
    });
  };


/** Function is used to send otp or email to reset password **/
this.forgotPassword = async (req, res, next)=> {
  req.body      = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
  let email     = (req.body.email) ? req.body.email : '';

  req.checkBody({	
    "email":{
      notEmpty		:true,
      isEmail			:{
        errorMessage:res.__("admin.user.please_enter_a_valid_email")
      },
      errorMessage	:res.__("admin.user.please_enter_an_email"),
    },
  })

  let errors  = parseValidationFront(req.validationErrors());
  errors      = (errors && Object.keys(errors).length>0) ? errors :  {};

  /** Check errors */
  if(Object.keys(errors).length == NOT){

    /*** Get random string */
    await getRandomString(VALIDATE_STRING_ROUND).then(responseString=>{
      let validateString   = (responseString.result) ? responseString.result : '';

      /** search condition */
      let searchCondition       = { is_deleted : NOT_DELETED};
      searchCondition['email']  = { $regex: new RegExp("^" + email, "i") }

      /** update condition */
      let conditionUpdate = {};
      conditionUpdate['validate_string']  = validateString;

      let collection = db.collection('users');
      collection.findOneAndUpdate(searchCondition,{$set:conditionUpdate},{"projection": {full_name:1, email:1}}, (err, result)=>{
        if(!err && result && result.lastErrorObject.updatedExisting  == true){

          /*** Send an email */
          let validateURL     = WEBSITE_FRONT_URL+'/user/reset-password/?validate_string='+validateString;
          let emailOptions = {
            action      : 'forgot_password',
            to          : result.value.email,
            rep_array   : [result.value.full_name, validateURL, validateURL]
          };
          sendEmail(req, res,emailOptions);
          
          /*** return success */
          return res.send({
            status		:	API_STATUS_SUCCESS,
            message		:	res.__("front.user.link_has_been_sent_on_your_registered_email"),
            result    : {validate_string : validateString},
            error		  :	[],
          });
        }else{
          /*** return error */
          return res.send({
            status		:	API_STATUS_ERROR,
            message		:	res.__("front.user.email_does_not_exist_in_our_database"),
            result    : {},
            error		  :	[],
          });
        }
      });
    }).catch(next);
  }else{
    /*** return error */
    return res.send({
      status		:	API_STATUS_ERROR,
      message		:	'',
      result    : {},
      error		  :	errors,
    });
  }
}


  /** Function is used to reset password **/
  this.resetPassword = async (req, res,next)=> {
    req.body            = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let validateString  = (req.body.validate_string)  ? req.body.validate_string : '';
    let password        = (req.body.password)         ? req.body.password : '';
    let confirmPassword = (req.body.confirm_password) ? req.body.confirm_password : '';

    if(!validateString) return res.send({
      status		:	API_STATUS_ERROR,
      message		:	res.__("front.user.invalid_request"),
      result    : {},
      error		  :	[],
    });

    req.checkBody({	
      "password":{
        isLength		:{
          options    : {min : PASSWORD_MIN_LENGTH , max : PASSWORD_MAX_LENGTH},
          errorMessage:res.__("admin.user.password_should_be_6_characters_long")
        },
        matches	 : {
          options    	: PASSWORD_ALPHANUMERIC_REGEX,
          errorMessage:res.__("admin.user.password.it_should_be_alphanumeric")
        },
        notEmpty		:true,
        errorMessage	:res.__("admin.user.please_enter_password")
      },
      "confirm_password":{ 
        isLength		:{
          options    : {min :PASSWORD_MIN_LENGTH,  max : PASSWORD_MAX_LENGTH},
          errorMessage:res.__("admin.user.password.it_should_be_6_characters_long")
        },
        matches	 : {
          options    	: PASSWORD_ALPHANUMERIC_REGEX,
          errorMessage:res.__("admin.user.password.it_should_be_alphanumeric")
        },
        notEmpty : true,
        errorMessage	:res.__("admin.user.please_enter_confirm_password")	
      },
    });

    /** Match password with confirm password */
    if (password && confirmPassword) {
      req.checkBody("confirm_password", "admin.user.password_does_not_matched").equals(req.body.password);
    }

    let encryptPassword 	= bcrypt.hashSync(password, BCRYPT_PASSWORD_SALT_ROUNDS);
    let errors  = parseValidationFront(req.validationErrors());
    errors      = (errors && Object.keys(errors).length>0) ? errors :  {};

    if(Object.keys(errors).length == 0){

        /** search condition */
      let conditionSearch = { 
        is_deleted  : NOT_DELETED, 
        is_active   : ACTIVE,
        validate_string : validateString
      };
  
      /** update condition */
      let conditionUpdate = {password : encryptPassword};

      let collection = db.collection('users');
      collection.updateOne(conditionSearch,{$set:conditionUpdate},(err, result)=>{
        if(!err && result && result.modifiedCount > NOT){
          return res.send({
            status		:	API_STATUS_SUCCESS,
            message		:	res.__("front.user.password_has_been_changed_successfully"),
            result    : {},
            error		  :	[],
          });
        }else{
          return res.send({
            status		:	API_STATUS_ERROR,
            message		:	res.__("admin.front.something_went_wrong_please_try_again_later")	,
            result    : {},
            error		  :	[],
          });
        }
      });
    }else{
      return res.send({
        status		:	API_STATUS_ERROR,
        message		:	'',
        result    : {},
        error		  :	errors,
      });
    }
  }

  /** Routing is used to get user data **/
  this.getUserDetail = async(req, res, next)=> {
    req.body         = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let languageId   = (req.body.language_id) ? req.body.language_id : '';
    let userId       = (req.body.user_id)     ? req.body.user_id : '';
    let slug         = (req.body.slug)        ? req.body.slug : '';

    
    /*** Set option to get user detail */
    let options = {
      conditions : {is_deleted: NOT_DELETED, is_active : ACTIVE, slug : slug, _id : ObjectId(userId)},
      fields     : {
        cityDetail : 0,
        countryDetail : 0,
        password : 0,
        otp :0,
        is_active : 0, 
        is_deleted: 0,
        email_link_expired    :0,
        phone_validate_string :0,
        email_validate_string :0
      }
    }

    /*** Get user detail */
    const collection = db.collection("users");
    collection.aggregate([
        {$match : options.conditions},
        {$lookup:{
          from: "masters",
          let: { countryId: "$country_name" },
          pipeline: [
            {$match: {$expr: {
                  $and: [
                    { $eq: ["$_id", "$$countryId"] },
                  ],
                },
             }},
          ],
          as: "countryDetail",
        }},
        {$lookup:{
          from: "masters",
          let: { city_name: "$city_name" },
          pipeline: [
             {$match: {
                $expr: {
                  $and: [
                    { $eq: ["$_id", "$$city_name"] },
                  ],
                },
             }},
          ],
          as: "cityDetail",
        }},
        {$lookup:{
          from: "masters",
          let: { nationality: "$nationality" },
          pipeline: [
             {$match: {
                $expr: {
                  $and: [
                    { $eq: ["$_id", "$$nationality"] },
                  ],
                },
             }},
          ],
          as: "nationalityDetail",
        }},
        {$addFields:{
          full_image_path : USERS_URL,
          country : {'$arrayElemAt': ["$countryDetail.text",0]},
          city    : {'$arrayElemAt': ["$cityDetail.text",0]},
          nationality_name : {'$arrayElemAt': ["$nationalityDetail.text",0]},
        }},
        {$project:options.fields}
      ]).toArray((err, result)=>{
        if(err) return next();

        /** return success */
        return res.send({
          status		:	API_STATUS_SUCCESS,
          message		:	'',
          result    : (result && result.length > NOT) ? result[0] : {},
          error		  :	{},
        });
    })
  }

  /** Function is used to update user profile **/
  this.profileSetup  = async(req, res, next)=> {
   
    req.body          = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let userId        = (req.body.user_id)        ? req.body.user_id:'';
    let slug          = (req.body.slug)           ? req.body.slug:'';
    let profileStep   = (req.body.update_profile_step)  ? req.body.update_profile_step:'';
    let profileSubmit = (req.body.profile_step_submit)  ? req.body.profile_step_submit:'';


    /** Check invalid request*/
    if(!userId || !slug || !profileStep) return res.send({
      status    : API_STATUS_ERROR,
      message   : res.__("front.user.invalid_request"),
      result    : {},
      error     : [],
    });

    /** set to search data */
    let conditionSearch = {
      _id         :  ObjectId(userId),
      slug        :  slug,
      is_deleted  :  NOT_DELETED
    };

    /** set to update data */
    let updateData = {
      update_profile_step : profileStep,
      profile_step_submit : profileSubmit,
      modified        : new Date()
    };

    /** set validation */
    let errors  = parseValidationFront(req.validationErrors());
    errors      = (errors && Object.keys(errors).length > NOT) ? errors :  {};

    /** Personal info step*/
    if(profileStep == "personal_info"){
      req.checkBody({ 
        "full_name":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_enter_full_name")
        },
        "gender":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_enter_gender")
        },
        "country_name":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_select_country")
        },
        "city_name":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_select_city")
        },
        "currency":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_select_currency")
        },
      });

      let gender        = (req.body.gender)         ? req.body.gender:'';
      let countryName   = (req.body.country_name)   ? req.body.country_name:'';
      let cityName      = (req.body.city_name)      ? req.body.city_name:'';
      let currency      = (req.body.currency)       ? req.body.currency:'';
      let fullName      = (req.body.full_name)      ? req.body.full_name:'';

      updateData['full_name'] = fullName;
      updateData['currency'] = currency;
      updateData['city_name'] = ObjectId(cityName);
      updateData['country_name'] = ObjectId(countryName);
      updateData['gender'] = gender;
      updateProfileDetail(req,res,errors,conditionSearch,updateData)  
    }


    /** Profile_picture and id image step*/
    if(profileStep == "upload_picture"){
      if(!req.files && !req.body.old_profile_image){
          Object.assign(errors, {'profile_image' : res.__("admin.user.please_select_image")})
         // errors.push({'param':'profile_image','msg':res.__("admin.user.please_select_image")});
      }
      // if(!req.files || !req.files.id_image){
        //Object.assign(errors, {'id_image' : res.__("admin.user.please_select_image")})
      // }


      let profileImage    =   (req.files && req.files.profile_image)  ?   req.files.profile_image :"";
      if(profileImage){
        let imgaeOptionsProfile    =   {
          'image'     :   profileImage,
          'filePath'  :   USERS_FILE_PATH
        };

        /** Upload user  image **/
        await moveUploadedFile(req, res,imgaeOptionsProfile).then(imgaeResponse=>{
          if(imgaeResponse.status == STATUS_ERROR){
              /** Send error response **/
              Object.assign(errors, {'profile_image' : imgaeResponse.message})
          }
          updateData['profile_image']    =  (imgaeResponse.fileName)    ?   imgaeResponse.fileName  : '';
        }).catch(next);
      }else{
        let oldProfileImage            = (req.body.old_profile_image) ? req.body.old_profile_image : '';
        updateData['profile_image']    =  oldProfileImage;
      }

      let profileIdProof    =   (req.files && req.files.profile_id_proof)  ?   req.files.profile_id_proof :"";
      if(profileIdProof){
        let imgaeOptionsProfile    =   {
          'image'     :   profileIdProof,
          'filePath'  :   USERS_FILE_PATH
        };

        /** Upload user  image **/
        await moveUploadedFile(req, res,imgaeOptionsProfile).then(imgaeResponse=>{
          if(imgaeResponse.status == STATUS_ERROR){
              /** Send error response **/
              Object.assign(errors, {'profile_id_proof' : imgaeResponse.message})
          }
          updateData['profile_id_proof']    =  (imgaeResponse.fileName)    ?   imgaeResponse.fileName  : '';
        }).catch(next);
      }else{
        let oldProfileImage            = (req.body.old_profile_id_proof) ? req.body.old_profile_id_proof : '';
        updateData['profile_id_proof']    =  oldProfileImage;
      }
      updateProfileDetail(req,res,errors,conditionSearch,updateData)  
    }// End Profile picture and id image step

    /** Category step*/
    if(profileStep == "category_info"){
      let category = (req.body.category) ? req.body.category : [];
      let subCategory = (req.body.sub_category) ? req.body.sub_category : [];
      //if(!category || category.length == NOT) Object.assign(errors, {'category' : res.__("front.user.please_select_category")})
      if(!subCategory || subCategory.length == NOT) Object.assign(errors, {'sub_category' : res.__("front.user.please_select_category")})

      //updateData['category'] = arrayToObject(category);
      updateData['sub_category'] = arrayToObject(subCategory);
      updateProfileDetail(req,res,errors,conditionSearch,updateData) 
    }


    /** qualification info step*/
    if(profileStep == "qualification_info"){
      	updateData['education'] = {};

      	let academic      = (req.body.academic) ? req.body.academic : [];
      	let professional  = (req.body.professional) ? req.body.professional : [];

      	if(academic.length == NOT) Object.assign(errors, {'academic' : res.__("admin.user.please_enter_academic_detail")})
      	if(professional.length == NOT) Object.assign(errors, {'professional' : res.__("admin.user.please_enter_professional_detail")})
      	
      	updateData['education']['academic'] 		= academic
      	updateData['education']['professional'] 	= professional

  		/** Set certificate value in professional array */
      	if(professional.length > NOT){
	        asyncForEachOf(professional, async(row, index, callback) => {
	    		if(!row.certification_file && !row.old_certification_file){
		          	Object.assign(errors, {'certification_file' : res.__("admin.user.please_select_certificate")})
		      	}
            
		      	if(row.certification_file){
		      		let file    =   (row.certification_file)  ?   row.certification_file : '';
	          	let options =   {
	              	'image'     		    : file,
	              	'data_format'     	: 'base_64',
	              	'filePath'  		    : USERS_FILE_PATH,
	              	'allowedExtensions' : ALLOWED_FILE_EXTENSIONS,
	              	'allowedImageError' : ALLOWED_FILE_ERROR_MESSAGE,
	              	'allowedMimeTypes' 	: ALLOWED_FILE_MIME_EXTENSIONS,
	              	'allowedMimeError' 	: ALLOWED_FILE_MIME_ERROR_MESSAGE
	          	};

		          	/** Upload certificate **/
		          	await moveUploadedFile(req, res, options).then(response=>{
		            	if(response.status == STATUS_ERROR){
		                	/** Send error response **/
		                	Object.assign(errors, {'certification_file' : response.message})
		            	}

		            	updateData['education']['professional'][index]['certification_file']  =  (response.fileName)    ?   response.fileName  :"";
		          	});
		          }else{
                let oldCertificatitonFile = (row.old_certification_file) ? row.old_certification_file :'';
                updateData['education']['professional'][index]['certification_file']  =  oldCertificatitonFile;
		          	updateProfileDetail(req,res,errors,conditionSearch,updateData)
		          }
	          	callback(err, null);
	        }, err => {
	            updateProfileDetail(req,res,errors,conditionSearch,updateData) 
	        });
	    }
    }

     /** professional info step*/
    if(profileStep == "professional_info"){
      updateData['professional'] = {};
      let experience=   (req.body.experience) ? JSON.parse(req.body.experience) : [];
      let languages =   (req.body.languages) ? JSON.parse(req.body.languages) : [];
      let oldResume =   (req.body && req.body.old_resume)  ?   req.body.old_resume :"";
      let resume    =   (req.files && req.files.resume)     ?   req.files.resume :"";

      if(!oldResume && !resume) Object.assign(errors, {'resume' : res.__("admin.user.please_upload_resume")})
      if(!languages || languages.length == NOT) Object.assign(errors, {'languages' : res.__("admin.user.please_select_language")})
      if(!experience || experience.length == NOT) Object.assign(errors, {'experience' : res.__("admin.user.please_enter_your_experience")})

      updateData['professional']['experience']  = (req.body.experience) ? JSON.parse(req.body.experience) : []
      updateData['professional']['languages']   = (req.body.languages)  ? JSON.parse(req.body.languages) : []
      updateData['professional']['description'] = (req.body.description) ? req.body.description : ''
      updateData['professional']['social_link'] = (req.body.social_link) ? JSON.parse(req.body.social_link) : {}

      let options    =   {
        'image'     :   resume,
        'filePath'  :   USERS_FILE_PATH,
        'oldPath'   :   oldResume,
        'allowedExtensions' : ALLOWED_FILE_EXTENSIONS,
        'allowedImageError' : ALLOWED_FILE_ERROR_MESSAGE,
        'allowedMimeTypes' : ALLOWED_FILE_MIME_EXTENSIONS,
        'allowedMimeError' : ALLOWED_FILE_MIME_ERROR_MESSAGE

      };

      /** Upload user  image **/
      await moveUploadedFile(req, res, options).then(response=>{
        if(response.status == STATUS_ERROR){
            /** Send error response **/
            Object.assign(errors, {'resume' : response.message})
        }
        updateData['professional']['resume']      =  (response.fileName)    ?   response.fileName  :"";
        updateProfileDetail(req,res,errors,conditionSearch,updateData)
      }).catch(next);
    }

    /** service info step*/
    if(profileStep == "service_info"){
      updateData['services'] = (req.body.services) ? req.body.services : [];
      updateProfileDetail(req,res,errors,conditionSearch,updateData) 
    }

    /** video info step*/
    if(profileStep == "video_info"){
      updateData['video'] = {};
      let type = (req.body.type) ? req.body.type : '';
      if(!type) Object.assign(errors, {'type' : res.__("front.user.please_select_type")})

      updateData['video']['type'] = type; 
      updateData['is_profile_step']  = (profileSubmit == 'next') ? ACTIVE : DEACTIVE;
      updateData['is_profile_updated']  = ACTIVE; 

      
      let file    =   (req.files && req.files.file)  ?   req.files.file :"";
      let url = (req.body.url != typeof undefined && req.body.url) ? req.body.url : '';
      if(!url && !file && !req.body.old_file) Object.assign(errors, {'url' : res.__("front.user.please_enter_video_url")})

      if(file){
        let options    =   {
            'image'     :   file,
            'filePath'  :   USERS_FILE_PATH,
            'allowedExtensions' : ALLOWED_VIDEO_EXTENSIONS,
            'allowedImageError' : ALLOWED_VIDEO_ERROR_MESSAGE,
            'allowedMimeTypes' : ALLOWED_VIDEO_MIME_EXTENSIONS,
            'allowedMimeError' : ALLOWED_VIDEO_MIME_ERROR_MESSAGE

        };

        /** Upload user  image **/
        await moveUploadedFile(req, res, options).then(response=>{
          if(response.status == STATUS_ERROR){
              /** Send error response **/
              Object.assign(errors, {'file' : response.message})
          }
          updateData['video']['file']  =  (response.fileName)    ?   response.fileName  :"";
          updateData['video']['url'] = url;
          updateProfileDetail(req,res,errors,conditionSearch,updateData) 
        }).catch(next);
      }else{
        updateData['video']['url'] = url;
        let file = (req.body.old_file)    ?   req.body.old_file  :"";
        updateData['video']['file']  =  file;
        updateProfileDetail(req,res,errors,conditionSearch,updateData) 
      }
      

    }
  }// End profileSetup

   /** Function is used to signup user */
  updateProfileDetail    =  (req,res,errors,conditionSearch,updateData)=>{
    if(errors && Object.keys(errors).length == NOT){
      let collection = db.collection('users');
      collection.findOneAndUpdate(conditionSearch,{$set: updateData},{}, (err, result)=>{
        if(!err && result && result.lastErrorObject.updatedExisting  == true){
          /** return success */
          return res.send({
            status    : API_STATUS_SUCCESS,
            message   : res.__("front.user.profile_has_been_updated_successfully"),
            result    : {},
            error     : {},
          });
        }else{

          /** return error */
          return res.send({
            status    : API_STATUS_ERROR,
            message   : res.__("front.something_went_wrong_please_try_again_later"),
            result    : {},
            error     : {},
          });
        }
      });
    }else{
      return res.send({
        status  : API_STATUS_ERROR,
        error   : errors,
        result  : '',
        message : ''
      });
    }
  }



  /** Function is used to update user profile **/
  this.updateProfile  = async(req, res, next)=> {

    req.body          = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let userId        = (req.body.user_id)        ? req.body.user_id:'';
    let slug          = (req.body.slug)           ? req.body.slug:'';
    let profileStep   = (req.body.update_profile_step)   ? req.body.update_profile_step:'';
   
    /** Check invalid request*/
    if(!userId || !slug || !profileStep) return res.send({
      status    : API_STATUS_ERROR,
      message   : res.__("front.user.invalid_request"),
      result    : {},
      error     : [],
    });


    /** set to search data */
    let conditionSearch = {
      _id         :  ObjectId(userId),
      slug        :  slug,
      is_deleted  :  NOT_DELETED
    };

    /** set to update data */
    let updateData = {$set:{
      modified        : getUtcDate()
    }}

    /** set validation */
    let errors  = parseValidationFront(req.validationErrors());
    errors      = (errors && Object.keys(errors).length > NOT) ? errors :  {};

    /** Personal info step*/
    if(profileStep == "personal_info"){
      req.checkBody({ 
        "full_name":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_enter_full_name")
        },
        "gender":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_enter_gender")
        },
        "country_name":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_select_country")
        },
        "city_name":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_select_city")
        },
        "currency":{
          notEmpty    :true,
          errorMessage  :res.__("admin.user.please_select_currency")
        },
      });

      let gender        = (req.body.gender)         ? req.body.gender:'';
      let countryName   = (req.body.country_name)   ? req.body.country_name:'';
      let cityName      = (req.body.city_name)      ? req.body.city_name:'';
      let nationality   = (req.body.nationality)    ? req.body.nationality:'';
      let fullName      = (req.body.full_name)      ? req.body.full_name:'';
      let dateOfBirth   = (req.body.date_of_birth)	?	req.body.date_of_birth:'';
      updateData = {$set:{
        'full_name'   : fullName,
        'nationality' : ObjectId(nationality),
        'city_name'   : ObjectId(cityName),
        'country_name': ObjectId(countryName),
        'gender'      : gender,
        'date_of_birth'	:	newDate(dateOfBirth, GRAPH_DATE_FORMAT),
      }}
      editProfile(req,res,errors,conditionSearch,updateData)  
    }

   

    /** social info step*/
    if(profileStep == "social_info"){
      let socialLink = (req.body.social_link) ? req.body.social_link : {};
      updateData = {$set:{
        'modified' : getUtcDate(),
        'professional.social_link'   : socialLink
      }}
      editProfile(req,res,errors,conditionSearch,updateData)
    }


    /** Upload profile picture*/
    if(profileStep == "upload_picture"){
      
      let profileImage     = (req.files && req.files.profile_image) ? req.files.profile_image : '';
      let oldProfileImage  = (req.body.old_profile_image) ? req.body.old_profile_image : '';
      if(!profileImage && !oldProfileImage) Object.assign(errors, {'profile_image' : res.__("front.user.please_select_file")});

      /** File options **/
      let options =   {
          'image'             : profileImage,
          'oldPath'           : oldProfileImage,
          'filePath'          : USERS_FILE_PATH,
          'data_format'       : '',
          'allowedExtensions' : ALLOWED_IMAGE_EXTENSIONS,
          'allowedImageError' : ALLOWED_IMAGE_ERROR_MESSAGE,
          'allowedMimeTypes'  : ALLOWED_IMAGE_MIME_EXTENSIONS,
          'allowedMimeError'  : ALLOWED_IMAGE_MIME_ERROR_MESSAGE
      };

      /** Upload profile picture **/
      await moveUploadedFile(req, res, options).then(response=>{

        if(response.status == STATUS_ERROR){
            /** Send error response **/
            Object.assign(errors, {'profile_image' : response.message})
        }

        let fileName = (response.fileName)    ?   response.fileName  :"";
        updateData = {$set:{
          'modified' : getUtcDate(),
          'profile_image'   : fileName
        }}
        editProfile(req,res,errors,conditionSearch,updateData)
      })
    }

    /** Upload profile cover image */
    if(profileStep == "upload_cover_picture"){
      let profileCoverImage     = (req.files && req.files.profile_cover_image) ? req.files.profile_cover_image : '';
      let oldProfileCoverImage  = (req.body.old_profile_cover_image) ? req.body.old_profile_cover_image : '';
      if(!profileCoverImage && !oldProfileCoverImage) Object.assign(errors, {'profile_cover_image' : res.__("front.user.please_select_file")});

      /** File options **/
      let options =   {
          'image'             : profileCoverImage,
          'oldPath'           : oldProfileCoverImage,
          'filePath'          : USERS_FILE_PATH,
          'data_format'       : '',
          'allowedExtensions' : ALLOWED_IMAGE_EXTENSIONS,
          'allowedImageError' : ALLOWED_IMAGE_ERROR_MESSAGE,
          'allowedMimeTypes'  : ALLOWED_IMAGE_MIME_EXTENSIONS,
          'allowedMimeError'  : ALLOWED_IMAGE_MIME_ERROR_MESSAGE
      };

      /** Upload profile picture **/
      await moveUploadedFile(req, res, options).then(response=>{
        if(response.status == STATUS_ERROR){
            /** Send error response **/
            Object.assign(errors, {'profile_cover_image' : response.message})
        }

        let fileName = (response.fileName)    ?   response.fileName  :"";
        updateData = {$set:{
          'modified' : getUtcDate(),
          'profile_cover_image'   : fileName
        }}
        editProfile(req,res,errors,conditionSearch,updateData)
      })
    }

    /** setting info step*/
    if(profileStep == "setting_info"){
      let currency = (req.body.currency) ? req.body.currency : {};
      let language = (req.body.currency) ? ObjectId(req.body.language) : {};
      updateData = {$set:{
        'modified'   : getUtcDate(),
        'currency'   : currency,
        'language'   : language
      }}
      editProfile(req,res,errors,conditionSearch,updateData)
    }

    /** setting info email step*/
    if(profileStep == "email_info"){
      let newEmail  = (req.body.new_email) ? req.body.new_email:'';
      if(!newEmail) Object.assign(errors, {'new_email' : res.__("front.user.please_enter_your_email")});

      /** user email unique options */
      if(newEmail){
        let emailUniqueOptions = {
          table_name  : "users",
          field_value : newEmail,
          field_name  : 'email'
        };
    
        let isEmailUnique  = await checkUniqueValue(emailUniqueOptions);
        if(isEmailUnique && isEmailUnique.status == STATUS_ERROR){
          errors['new_email']= res.__("front.user.email_is_already_in_use_please_try_something_different")
        }else{
          if(Object.keys(errors).length == NOT){
            let fullName  = (req.body.full_name)      ? req.body.full_name:'';
            let roleId    = (req.body.role_id) ? req.body.role_id : '';
            await getRandomString(VALIDATE_STRING_ROUND).then(responseString=>{
              let emailValidateString   = (responseString.result) ? responseString.result : '';
              updateData['email_validate_string'] = emailValidateString;
              let userRole = (roleId == EXPERT_ROLE_ID) ? EXPERT_ROLE_NAME : STUDENT_ROLE_NAME;
    
              /***Send mail */
              let validateURL  = WEBSITE_API_URL+'/new_email_verification/'+emailValidateString+'/'+userRole;
              let emailOptions = {
                action        : 'update_email_verification',
                to            : newEmail,
                rep_array     : [fullName, validateURL, validateURL]
              };
              sendEmail(req, res,emailOptions);
            });
          }
          updateData = {$set:{'new_email'  : newEmail, 'modified' : getUtcDate()}}
          editProfile(req,res,errors,conditionSearch,updateData)
        }
      }
    }

     /** setting info phone step*/
    if(profileStep == "phone_info"){
      let newPhone  = (req.body.new_phone) ? req.body.new_phone:'';
      if(!newPhone) Object.assign(errors, {'new_phone' : res.__("front.user.please_enter_your_phone")});
      
      /** user mobile unique options */
      if(newPhone){
        let mobileUniqueOptions = {
          table_name  : "users",
          field_value : newPhone,
          field_name  : 'phone'
        };
    
        let isMobileUnique  = await checkUniqueValue(mobileUniqueOptions);
        if(isMobileUnique && isMobileUnique.status == STATUS_ERROR){
          errors['newPhone']= res.__("front.user.phone_is_already_in_use_please_try_something_different")
        }
      }

       /***Send SMS */
        // let phoneOptions = {
        //   mobile_number : (string) ? userResult.new_mobile : mobile,
        //   sms_template  : "OTP for new mobile verification "+ mobileValidateOTP
        // };
        // await sendSMS(req,res,phoneOptions);
      updateData = {$set:{'new_phone'  : newPhone, 'modified' : getUtcDate()}}
      editProfile(req,res,errors,conditionSearch,updateData)
    }

    /** setting info step*/
    if(profileStep == "password_info"){
      let password               = (req.body.password)           ?  req.body.password:'';
      let confirmPassword        = (req.body.confirm_password)   ?  req.body.confirm_password:'';
      let encryptPassword        = bcrypt.hashSync(password, BCRYPT_PASSWORD_SALT_ROUNDS);

      /** Match password with confirm password */
      if (password && confirmPassword) {
        if(password != confirmPassword) Object.assign(errors, {'password' : res.__("admin.user.password_does_not_matched")});
      }

      updateData = {$set:{'password'  : encryptPassword, 'modified' : getUtcDate()}}
      editProfile(req,res,errors,conditionSearch,updateData)
    }

    /** academic nfo step*/
    if(profileStep == "academic_info"){
      let subjects= (req.body.subjects) ? req.body.subjects : {};
      let degree  = (req.body.degree) ? req.body.degree : {};
      let grade   = (req.body.grade) ? req.body.grade : {};
      let school  = (req.body.school) ? req.body.school : '';
      let year    = (req.body.year) ? req.body.year : '';
      let endYear    = (req.body.end_year) ? req.body.end_year : '';
      let id      = (req.body.id) ? req.body.id : NOT;
      let isEdit  = (req.body.is_edit) ? req.body.is_edit : '';
      let stillStudying  = (req.body.still_studying) ? req.body.still_studying : '';

      /** update record **/
      if(isEdit== 'true'){
        conditionSearch = {'_id' : ObjectId(userId), 'education.academic' : { $elemMatch: { 'id': id}}}
        updateData = {
          $set:{
            'modified' : getUtcDate(),
            'education.academic.$.subjects' : subjects,
            'education.academic.$.degree'   : degree,
            'education.academic.$.grade'    : grade,
            'education.academic.$.school'   : school,
            'education.academic.$.year'     : year,
            'education.academic.$.end_year' : endYear,
            'education.academic.$.still_studying' : stillStudying,
          }
        };
      }else{
        /** insert record **/
        updateData = {
          $push:{
            'education.academic'  : {
              'id'        : ObjectId().toString(),
              'subjects'  : subjects,
              'degree'    : degree,
              'grade'     : grade,
              'school'    : school,
              'year'      : year,
              'end_year'  : endYear,
              'still_studying':stillStudying,
              'created'   : getUtcDate()
            }
          }
        };
      }
      editProfile(req,res,errors,conditionSearch,updateData)
    }

    /** education professional info step*/
    if(profileStep == "professional_info"){
      let certificationName   = (req.body.certification_name) ? req.body.certification_name : '',
        certificateName       = (req.body.certificate_name) ? req.body.certificate_name : '',
        certificationNumber   = (req.body.certification_number) ? req.body.certification_number : '',
        institutionName       = (req.body.institution_name) ? req.body.institution_name : '',
        institutionEmail      = (req.body.institution_email) ? req.body.institution_email : '',
        institutionWebsite    = (req.body.institution_website) ? req.body.institution_website : '',
        certificationFile     = (req.files && req.files.certification_file) ? req.files.certification_file : '',
        oldCertificationFile  = (req.body.old_certification_file) ? req.body.old_certification_file : '',
        isEdit                = (req.body.is_edit) ? req.body.is_edit : '',
        id                    = (req.body.id) ? req.body.id : NOT;

      /*** Validation message **/
      if(!certificationName) Object.assign(errors, {'certification_name' : res.__("front.user.please_enter_certification_name")});
      if(!certificationNumber) Object.assign(errors, {'certification_number' : res.__("front.user.please_enter_certification_number")});
      if(!institutionName) Object.assign(errors, {'institution_name' : res.__("front.user.please_enter_institution_name")});
      if(!institutionEmail) Object.assign(errors, {'institution_email' : res.__("front.user.please_enter_institution_email")});
      if(!institutionWebsite) Object.assign(errors, {'institution_website' : res.__("front.user.please_enter_institution_website")});
      if(!certificationFile && !oldCertificationFile) Object.assign(errors, {'certification_file' : res.__("front.user.please_select_certification_file")});

      /** File options **/
      let options =   {
          'image'             : certificationFile,
          'oldPath'           : oldCertificationFile,
          'filePath'          : USERS_FILE_PATH,
          'data_format'       : '',
          'allowedExtensions' : ALLOWED_FILE_EXTENSIONS,
          'allowedImageError' : ALLOWED_FILE_ERROR_MESSAGE,
          'allowedMimeTypes'  : ALLOWED_FILE_MIME_EXTENSIONS,
          'allowedMimeError'  : ALLOWED_FILE_MIME_ERROR_MESSAGE
      };

      /** Upload certificate **/
      await moveUploadedFile(req, res, options).then(response=>{
        if(response.status == STATUS_ERROR){
            /** Send error response **/
            Object.assign(errors, {'certification_file' : response.message})
        }

        let fileName = (response.fileName)    ?   response.fileName  :"";

        /** update record **/
        if(isEdit== 'true'){
          conditionSearch['education.professional'] = { $elemMatch: { 'id': id}}
          updateData = {
            $set:{
              'modified' : getUtcDate(),
              'education.professional.$.certificate_name'       : certificateName,
              'education.professional.$.certification_name'     : certificationName,
              'education.professional.$.certification_number'   : certificationNumber,
              'education.professional.$.institution_email'      : institutionEmail,
              'education.professional.$.institution_website'    : institutionWebsite,
              'education.professional.$.institution_name'       : institutionName,
              //'education.professional.$.certification_file'     : fileName,
            }
          };
          editProfile(req,res,errors,conditionSearch,updateData)
        }else{
          /** Insert record **/
          updateData = {
            $push:{
              'education.professional'  : {
                'id'                   : ObjectId().toString(),
                'certification_name'   : certificationName,
                'certificate_name'     : certificateName,
                'certification_number' : certificationNumber,
                'institution_name'     : institutionName,
                'institution_email'    : institutionEmail,
                'institution_website'  : institutionWebsite,
                //'certification_file'   : fileName,
                'created'              : getUtcDate()
              }
            }
          };
          editProfile(req,res,errors,conditionSearch,updateData)
        }
      });
    }

   
    /** Work experience info step*/
    if(profileStep == "work_experience_info"){
      let title          = (req.body.title) ? req.body.title : '',
        employmentType   = (req.body.employment_type) ? req.body.employment_type : '',
        companyName      = (req.body.company_name) ? req.body.company_name : '',
        stillWorking     = (req.body.still_working) ? req.body.still_working : '',
        city             = (req.body.city_name) ? req.body.city_name : '',
        country          = (req.body.country_name) ? req.body.country_name : '',
        fromDate         = (req.body.from_date) ? req.body.from_date : '',
        toDate           = (req.body.to_date) ? req.body.to_date : '',
        description      = (req.body.description) ? req.body.description : '',
        isEdit           = (req.body.is_edit) ? req.body.is_edit : '',
        id               = (req.body.id) ? req.body.id : NOT;
        
      /*** Validation message **/
      if(!title) Object.assign(errors, {'title' : res.__("front.user.please_enter_title")});
      if(!employmentType) Object.assign(errors, {'employment_type' : res.__("front.user.please_select_employment_type")});
      if(!companyName) Object.assign(errors, {'company_name' : res.__("front.user.please_enter_company_name")});
      if(!stillWorking) Object.assign(errors, {'still_working' : res.__("front.user.please_enter_still_working")});
      if(stillWorking == 'no' && !toDate) Object.assign(errors, {'to_date' : res.__("front.user.please_select_to_date")});
      if(!city) Object.assign(errors, {'city_name' : res.__("front.user.please_select_city")});
      if(!country) Object.assign(errors, {'country_name' : res.__("front.user.please_select_country")});
      if(!fromDate) Object.assign(errors, {'from_date' : res.__("front.user.please_select_from_date")});
      if(!description) Object.assign(errors, {'description' : res.__("front.user.please_enter_description")});

      /** update record **/
      
      if(isEdit == 'true'){
        conditionSearch = {'_id' : ObjectId(userId), 'professional.experience' : { $elemMatch: { 'id': id}}}
        //conditionSearch['professional.experience'] = { $elemMatch: { 'id': id}}
        updateData = {
          $set:{
            'modified' : getUtcDate(),
            'professional.experience.$.title'             : title,
            'professional.experience.$.employment_type'   : JSON.parse(employmentType),
            'professional.experience.$.company_name'      : companyName,
            'professional.experience.$.still_working'     : stillWorking,
            'professional.experience.$.city_name'         : ObjectId(city),
            'professional.experience.$.country_name'      : ObjectId(country),
            'professional.experience.$.from_date'         : newDate(fromDate, GRAPH_DATE_FORMAT),
            'professional.experience.$.to_date'           : (stillWorking == 'no') ? newDate(toDate, GRAPH_DATE_FORMAT) : '',
            'professional.experience.$.description'       : description
          }
        };
        editProfile(req,res,errors,conditionSearch,updateData)
      }else{

        /** Insert record **/
        updateData = {
          $push:{
            'professional.experience'  : {
              'id'  : ObjectId().toString(),          
              'title' : title,
              'created' : getUtcDate(),
              'to_date'  : (stillWorking == 'no') ? newDate(toDate, GRAPH_DATE_FORMAT) : '',
              'from_date' : newDate(fromDate, GRAPH_DATE_FORMAT),
              'city_name'   : ObjectId(city),
              'description'   : description,
              'company_name'    : companyName,
              'country_name'      : ObjectId(country),
              'still_working'       : stillWorking,
              'employment_type'       : (isEdit == 'false') ? JSON.parse(employmentType) : employmentType
            }
          }
        };
        editProfile(req,res,errors,conditionSearch,updateData)
      }
    }

    /** Work experience resume info step*/
    if(profileStep == "work_experience_resume"){
      let resume   = (req.files && req.files.resume) ? req.files.resume : '';
      if(!req.files) Object.assign(errors, {'resume' : res.__("front.user.please_select_file")});

      /** File options **/
      let options =   {
          'image'             : resume,
          'filePath'          : USERS_FILE_PATH,
          'data_format'       : '',
          'allowedExtensions' : ALLOWED_FILE_EXTENSIONS,
          'allowedImageError' : ALLOWED_FILE_ERROR_MESSAGE,
          'allowedMimeTypes'  : ALLOWED_FILE_MIME_EXTENSIONS,
          'allowedMimeError'  : ALLOWED_FILE_MIME_ERROR_MESSAGE
      };

      /** Upload certificate **/
      await moveUploadedFile(req, res, options).then(response=>{
        if(response.status == STATUS_ERROR){
            /** Send error response **/
            Object.assign(errors, {'resume' : response.message})
        }

        /** update record **/
        let fileName = (response.fileName)    ?   response.fileName  :"";
        updateData = {
          $set:{
            'modified' : getUtcDate(),
            'professional.modified' : getUtcDate(),
            'professional.resume'  : fileName
          }
        };
        editProfile(req,res,errors,conditionSearch,updateData)
      });
    }

    /** Work experience description info step*/
    if(profileStep == "work_experience_bio_description"){
      let description   = (req.body && req.body.description) ? req.body.description : '';
      if(!description) Object.assign(errors, {'description' : res.__("front.user.please_enter_description")});

      /** update record **/
      updateData = {
        $set:{
          'modified' : getUtcDate(),
          'professional.modified' : getUtcDate(),
          'professional.description'  : description
        }
      };
      editProfile(req,res,errors,conditionSearch,updateData)
    }

    /** Work experience language info step*/
    if(profileStep == "work_experience_language"){
      let languages   = (req.body && req.body.languages) ? req.body.languages : '';
      if(!languages) Object.assign(errors, {'languages' : res.__("front.user.please_select_language")});

      /** update record **/
      updateData = {
        $set:{
          'modified' : getUtcDate(),
          'professional.modified' : getUtcDate(),
          'professional.languages'  : languages
        }
      };
      editProfile(req,res,errors,conditionSearch,updateData)
    }

  }// End updateProfile



  /** Function is used to update user detail */
  editProfile    =  (req,res,errors,conditionSearch,updateData)=>{
    if(errors && Object.keys(errors).length == NOT){
      let collection = db.collection('users');
      collection.findOneAndUpdate(conditionSearch,updateData, (err, result)=>{
        if(!err){

          /** return success */
          return res.send({
            status    : API_STATUS_SUCCESS,
            message   : res.__("front.user.profile_has_been_updated_successfully"),
            result    : {},
            error     : {},
          });
        }else{
          /** return error */
          return res.send({
            status    : API_STATUS_ERROR,
            message   : res.__("front.something_went_wrong_please_try_again_later"),
            result    : {},
            error     : {},
          });
        }
      });
    }else{
      return res.send({
        status  : API_STATUS_ERROR,
        error   : errors,
        result  : '',
        message : ''
      });
    }
  }

  /** Function is used to delete profile data */
  this.deleteProfileData  = (req, res, next)=> {
    let type    = (req.body.type) ? req.body.type : '';
    let userId  = (req.body.user_id) ? req.body.user_id : '';
    let slug    = (req.body.slug) ? req.body.slug : '';
    let id      = (req.body.id) ? req.body.id : '';
    let languageId  = (req.body.language_id) ? req.body.language_id : '';

    if(!userId || !slug || !id) return res.send({
      status		:	API_STATUS_ERROR,
      message		:	res.__("front.user.invalid_request"),
      result    : {},
      error		  :	[],
    });

    let condition = {_id :  ObjectId(userId)};
    let updateCondition = {$set:{}}
    if(type == 'work_experience_info') {  
      updateCondition = { $pull: { 'professional.experience': { id : id} } }
    }

    if(type == 'academic_info') {
      updateCondition = { $pull: { 'education.academic': {id : id } } }
    }

    if(type == 'professional_info') {
      updateCondition = { $pull: { 'education.professional':  { id : id } } }
    }

    let collection = db.collection('users');
    collection.updateOne(condition,updateCondition,(err, result)=>{
      if(!err){

        /** return success */
        return res.send({
          status    : API_STATUS_SUCCESS,
          message   : res.__("front.user.profile_has_been_updated_successfully"),
          result    : {},
          error     : {},
        });
      }else{
        /** return error */
        return res.send({
          status    : API_STATUS_ERROR,
          message   : res.__("front.something_went_wrong_please_try_again_later"),
          result    : {},
          error     : {},
        });
      }
    });
  }
}
module.exports = new User();