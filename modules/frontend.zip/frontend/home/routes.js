/** Model file path for current plugin **/
const modelPath     =	__dirname+"/model/home";
const home	        =   require(modelPath);

/** Routing is used to get home data **/
routes.post(API_URL+"home_data",(req,res,next)=>{
    home.getHomeData(req,res,next);
});

/** Routing is used to get country list **/
routes.post(API_URL+"masters",(req,res,next)=>{
    home.getMasterList(req,res,next);
});

/** Routing is used to get country list **/
routes.post(API_URL+"country",(req,res,next)=>{
    home.getCountryList(req,res,next);
});

/** Routing is used to get city list **/
routes.post(API_URL+"city",(req,res,next)=>{
    home.getCityList(req,res,next);
});

/** Routing is used to get category list **/
routes.post(API_URL+"category",(req,res,next)=>{
    home.getCategoryList(req,res,next);
});

/** Routing is used to get sub_category list **/
routes.post(API_URL+"sub_category",(req,res,next)=>{
    home.getSubCategoryList(req,res,next);
});

/** Routing is used to get language list **/
routes.post(API_URL+"language",(req,res,next)=>{
    home.getLanguagesList(req,res,next);
});

/** Routing is used to get service list **/
routes.post(API_URL+"service",(req,res,next)=>{
    home.getMasterList(req,res,next);
});

/** Routing is used to subscribe newsletter **/
routes.post(API_URL+"newsletter",(req,res,next)=>{
    home.newsletter(req,res,next);
});