const asyncParallel		= require("async/parallel");
const asyncForEachOf  	= require("async/forEachOf");
const { ObjectId }      = require("mongodb");
function Home(req, res) {

  /** Function is to get home page data **/
  this.getHomeData = (req, res)=> {
    let languageId = (req.body.language_id) ? req.body.language_id : DEFAULT_LANGUAGE_MONGO_ID;
    asyncParallel(
      {
        slider: (callback) => {
          const collection = db.collection("slider");
          collection.aggregate([
            {$match:{
              status : ACTIVE
            }},
            {$project:{
                slider_image:1,
                title: "$slider_descriptions."+languageId+".title",
                description: "$slider_descriptions."+languageId+".description"
              }
            }
          ]).toArray((err, result) => {
            let options = {
              database_field : 'slider_image',
              file_url    : SLIDERS_URL,
              file_path   : SLIDERS_FILE_PATH,
              result  : result,
            };
            appendFileExistData(options).then((response) => {
              let result = response.result ? response.result : [];
              callback(err, result);
            });
          });
        },
        testimonials: (callback) => {
          const collection = db.collection("testimonials");
          collection.aggregate([
            {$match:{
              is_deleted : NOT_DELETED
            }},
            {$project:{
                rating:1, created:1,
                description: "$pages_descriptions."+languageId+".body"
              }
            }
          ]).toArray((err, result) => {
            let options = {
              file_url    : TESTIMONIAL_FILE_URL,
              result  : result,
            };
            appendFileExistData(options).then((response) => {
              let result = response.result ? response.result : [];
              callback(err, result);
            });
          });
        },
        blocks: (callback) => {
          const collection = db.collection("pages");
          collection.aggregate([
           {$project:{
              slug :1,
              body: "$pages_descriptions."+languageId+".body"
            }}
          ]).toArray((err, result) => { 
            let data      = {};
            result.map((row, index)=>{
              data[row.slug] = row;
            })
            callback(err, data);
          });
        },
        settings: (callback) => {
          const collection = db.collection("settings");
          collection.find({type : {$in: ['Social', 'Contact']}}).toArray((err, result) => {
              let data      = {};
              result.map((row, index)=>{
                data[row.key_value] = row.value;
              })
            callback(err, data);
          });
        },
      },
      (err, response) => {
        /** Send error message */
        if(err){
          return res.send({
            status    : API_STATUS_ERROR,
            result    : [],
            message   : ''
          });
        }else{
          return res.send({
            status    : API_STATUS_SUCCESS,
            result    : response,
            message   : ''
          });
        }
      }
    );
  };

  /** Function is to get meta detail */
  this.getMetaDetail = (req, res)=> {
    let pageName  = (req.params && req.params.page_name)  ? req.params.page_name : '';
    if(!pageName) return res.send({status : API_STATUS_SUCCESS,result : {}});
    const collection = db.collection("meta_title_description");
    collection.findOne({ is_active : ACTIVE, is_deleted  : NOT_DELETED, slug  : pageName},{$projection:{description : 1,title_tag : 1}},(err, result) => {
        if(!err){
          return res.send({
            status    : API_STATUS_SUCCESS,
            result    : (result) ? result : {},
            message   : ''
          });
        }else{
          return res.send({
            status      : API_STATUS_ERROR,
            result      : {},
            message     : res.__("front.system.something_went_wrong")
          });
        }
      }
    )
  }

  /** Function is to get cms */
  this.getCms = (req, res)=> {
    let languageId = (req.body.language_id) ? req.body.language_id : DEFAULT_LANGUAGE_MONGO_ID;
    let slug  = (req.body && req.body.slug)  ? req.body.slug : '';
    if(!slug) return res.send({status    : API_STATUS_ERROR,result    : {},message   : res.__("front.system.data_missing")});
    const collection = db.collection("cms");
    collection.aggregate([
      {$match:{
        is_active   : ACTIVE, 
        is_deleted  : NOT_DELETED, 
        slug        : slug
      }},
      {$project:{
        description : "$pages_descriptions."+languageId+".body",
        title       : "$pages_descriptions."+languageId+".title"
      }}
      ]).toArray((err, result) => {
        if(!err){
          return res.send({
            status    : API_STATUS_SUCCESS,
            result    : (result) ? result[0] : {},
            message   : ''
          });
        }else{
          return res.send({
            status      : API_STATUS_ERROR,
            result      : {},
            message     : res.__("front.system.something_went_wrong")
          });
        }
      }
    )
  }


  /** Function is to get settings */
  this.getSetting = (req, res)=> {
    const collection = db.collection("settings");
    collection.aggregate([
      {$project : {
        key_value : 1,
        value     : 1,
      }}
    ]).toArray((err, result) => {
        if(!err && result && result.length> NOT){
          let data      = {};
          result.map((row, index)=>{
            data[row.key_value] = row.value;
          })

          return res.send({
            status    : API_STATUS_SUCCESS,
            result    : (data) ? data : {},
            message   : ''
          });
        }else{
          return res.send({
            status      : API_STATUS_ERROR,
            result      : {},
            message     : res.__("front.system.something_went_wrong")
          });
        }
      }
    )
  }


    /** Function is to get master list */
  this.getMasterList = (req, res,next)=> {
    req.body  = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let languageId  = (req.body.languageId) ? req.body.languageId : ENGLISH_LANGUAGE_MONGO_ID;
    let dropdownType = (req.body.dropdown_type) ? req.body.dropdown_type : '';

    const collection = db.collection("masters");
    collection.find({"status"   : ACTIVE, "dropdown_type" : dropdownType},{projection: {_id :1, name: 1,master_descriptions:1}}).toArray((err, result) => {
      if(err) return next();
      let newResult = [];
      asyncForEachOf(result, (row, index,callback) => {
        newResult[index] = {_id : row._id, name : (row.master_descriptions && row.master_descriptions[languageId]) ? row.master_descriptions[languageId]['name'] : row.name}
        callback(err, newResult);
      }, err => {
        if(err) return next();
          return res.send({
            status          : API_STATUS_SUCCESS,
            result          : (newResult) ? newResult : [],
            message         : ''
          });
        })
      }
    )
  }

  /** Function is to get country list */
  this.getCountryList = (req, res,next)=> {
    req.body  = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let languageId = (req.body.languageId) ? req.body.languageId : ENGLISH_LANGUAGE_MONGO_ID
    const collection = db.collection("masters");
    collection.find({"status"   : ACTIVE, "dropdown_type" : "country"},{projection: {_id :1, name : 1, image:1, text:1,master_descriptions:1}}).toArray((err, result) => {
      if(err) return next();
      let newResult = [];
      asyncForEachOf(result, (row, index,callback) => {
        newResult[index] = {id : row._id, text : (row.master_descriptions && row.master_descriptions[languageId]) ? row.text : row.text}
        callback(err, newResult);
      }, err => {
        if(err) return next();
          return res.send({
            status          : API_STATUS_SUCCESS,
            result          : (newResult) ? newResult : [],
            message         : ''
          });
        })
      }
    )
  }

  /** Function is to get city list */
  this.getCityList = (req, res,next)=> {
    req.body  = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let languageId = (req.body.languageId) ? req.body.languageId : ENGLISH_LANGUAGE_MONGO_ID;
    let countryId  = (req.body.countryId)  ? req.body.countryId  : ENGLISH_LANGUAGE_MONGO_ID;


    const collection = db.collection("masters");
    collection.find({"status"   : ACTIVE, "dropdown_type" : "city", "country_id": ObjectId(countryId)},{projection: {_id :1, name:1, text:1, master_descriptions:1}}).toArray((err, result) => {
      if(err) return next();
      let newResult = [];
      asyncForEachOf(result, (row, index,callback) => {
        newResult[index] = {id : row._id, text : (row.master_descriptions && row.master_descriptions[languageId]) ? row.text : row.text}
        callback(err, newResult);
      }, err => {
        if(err) return next();
          return res.send({
            status          : API_STATUS_SUCCESS,
            result          : (newResult) ? newResult : [],
            message         : ''
          });
        })
      }
    )
  }

    /** Function is to get category list */
  this.getCategoryList = (req, res,next)=> {
    req.body  = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let languageId = (req.body.languageId) ? req.body.languageId : ENGLISH_LANGUAGE_MONGO_ID
    const collection = db.collection("categories");
    collection.aggregate([
      {$match:{
        "parent_id" : {$exists : false}
      }},
      {$lookup:{
        from: "categories",
        let: { categoryId: "$_id" },
        pipeline: [
           {$match: {
              $expr: {
                $and: [
                  { $eq: ["$parent_id", "$$categoryId"] },
                ],
              },
           }},
           {$project:{_id :1, descriptions:1}},
        ],
        as: "subcategoryList",
      }},
      {$project: {
        _id :1, descriptions:1,
        subcategories : '$subcategoryList',
      }}
    ]).toArray((err, result) => {
      if(err) return next();
      let newResult = [];
      asyncForEachOf(result, (row, index,callback) => {
        newResult[index] = {_id : row._id, name : (row.descriptions[languageId]) ? row.descriptions[languageId]['name'] : ''}
        let subcategoriesList = (row.subcategories) ? row.subcategories : [];
        if(subcategoriesList.length > NOT){
          let subcategoriesListResult = [];
          asyncForEachOf(subcategoriesList, (subcategoriesRow, subcategoriesIndex, asyncCallback) => {
            let subcategories = {_id : subcategoriesRow._id, name : (subcategoriesRow.descriptions[languageId]) ? subcategoriesRow.descriptions[languageId]['name'] : ''}
            subcategoriesListResult[subcategoriesIndex] = subcategories;
              newResult[index]['subcategories'] = subcategoriesListResult
            asyncCallback('', newResult);
          }, error => {
            callback(error, newResult);
          })
        }else{
          callback(err, newResult);
        }
      }, err => {

        if(err) return next();
        return res.send({
          status   : API_STATUS_SUCCESS,
          result   : (newResult) ? newResult : [],
          message  : ''
        });
      })
    })
  }

  /** Function is to get sub category list */
  this.getSubCategoryList = (req, res,next)=> {
    req.body  = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    let languageId = (req.body.languageId) ? req.body.languageId : ENGLISH_LANGUAGE_MONGO_ID;
    let categoryId  = (req.body.categoryId)  ? req.body.categoryId : [];

    categoryId = arrayToObject(categoryId)
    /*** Send error*/
    let errors = {};
    if(!categoryId || categoryId.length == NOT) Object.assign(errors, {'category' : res.__("front.user.please_select_category")})
    if(errors && Object.keys(errors).length != NOT){
    	return res.send({
		    status  : API_STATUS_ERROR,
		    error   : errors,
		    result  : '',
		    message : ''
	  	});
    }

    const collection = db.collection("categories");
    collection.find({"parent_id": {$in: categoryId}},{projection: {_id :1, descriptions:1}}).toArray((err, result) => {
      if(err) return next();
      let newResult = [];
      asyncForEachOf(result, (row, index,callback) => {
        newResult[index] = {_id : row._id, name : (row.descriptions[languageId]) ? row.descriptions[languageId]['name'] : ''}
        callback(err, newResult);
      }, err => {
        if(err) return next();
          return res.send({
            status          : API_STATUS_SUCCESS,
            result          : (newResult) ? newResult : [],
            message         : ''
          });
        })
      }
    )
  }


  /** Function is to get country list */
  this.getLanguagesList = (req, res, next)=> {
    req.body  = sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
    const collection = db.collection("languages");
    collection.find({},{projection :{_id : 1,title:1, lang_code :1}}).toArray((err, result) => {
        if(err) return next();
        return res.send({
          status          : API_STATUS_SUCCESS,
          result          : (result) ? result : [],
          message         : ''
        });
      }
    )
  }

    /** Function is used to save contact us detail**/
    this.contactUs = async(req, res, next)=> {
      req.body      = sanitizeData(req.body, NOT_ALLOWED_TAGS);
      req.checkBody({	
        "name":{
          notEmpty		:true,
          errorMessage	:res.__("front.this_field_is_required")
        },
        "email":{
          notEmpty		:true,
          errorMessage	:res.__("front.this_field_is_required")
        },
        "mobile":{
          notEmpty		:true,
          errorMessage	:res.__("front.this_field_is_required")
        },
        "subject":{
          notEmpty		:true,
          errorMessage	:res.__("front.this_field_is_required")
        },
        "message":{
          notEmpty		:true,
          errorMessage	:res.__("front.this_field_is_required")
        },
      });
  
      
      let name      = (req.body.name)     ? req.body.name :'';
      let email     = (req.body.email)    ? req.body.email :'';
      let mobile    = (req.body.mobile)   ? req.body.mobile :'';
      let subject   = (req.body.subject)  ? req.body.subject :'';
      let message   = (req.body.message)  ? req.body.message :'';
  
  
      /** Set insertable data */
      let insertData = {
        name      : name,
        email     : email,
        mobile    : mobile,
        subject   : subject,
        message   : message,
        created   : getUtcDate()
      }
  
      let errors  = parseValidation(req.validationErrors());
      errors      = (errors && errors.length>NOT) ? errors :  [];

      if(errors && errors.length == NOT){
        const collection	=	db.collection("contact_us");
        collection.insert(insertData, async(error,result)=>{
          if(!error){

            /*** Start send notification */
              let notificationMessageParams = [];
              let currentTemplates        = await notificationTemplates(req,res,NOTIFICATION_USER_CONTACT_US); 
              let notificationOptions = {
                notification_data : {
                  notification_title    : (currentTemplates.subject)     ? currentTemplates.subject :'',
                  notification_message  : (currentTemplates.description) ? currentTemplates.description :'',
                  message_params        : notificationMessageParams,
                  user_id               : [DEFAULT_MONGOID]
                }
              };
              await insertNotifications(req,res,notificationOptions);
            /*** End send notification */


            return res.send({
              status        : API_STATUS_SUCCESS,
              error         : [],
              result        : '',
              message       : res.__("front.user.thanks_for_contact_us"),
            })
          }else{
            return res.send({
              status        : API_STATUS_ERROR,
              error         : [],
              result        : '',
              message       : res.__("front.something_went_wrong_please_try_again_later"),
            })
          }
        })
      }else{
        res.send({
          status	:	API_STATUS_ERROR,
          error		:	errors,
          result  : '',
          message : ''
        });
      }
    }

  /**
   * Function for newsletter
   *
   * @param req   As Request Data
   * @param res   As Response Data
   *
   * @return json
   */
  this.newsletter = (req, res, next) => {
    if(isPost(req)){

      /** Sanitize Data **/
      req.body  = sanitizeData(req.body,NOT_ALLOWED_TAGS_XSS);
      let email = (req.body.email)  ? req.body.email  :"";
      let language = (req.body.language)  ? req.body.language  :"";
      
      /** Check validation **/
      req.checkBody({
        "email": {
          notEmpty: true,
          errorMessage: res.__("front.newsletter_subscriber.please_enter_email"),
          isEmail: {
            errorMessage: res.__("front.newsletter_subscriber.please_enter_valid_email_address")
          },
        },
      });
      
      /** parse Validation array  **/
      let errors = parseValidationFront(req.validationErrors(),req);
      
      /** Send error response **/
      if(errors) return res.send({status : API_STATUS_ERROR,message : errors});
      
      /** Configure newsletter subscribers unique conditions **/
      const newsletter_subscribers = db.collection("newsletter_subscribers");
      newsletter_subscribers.findOne({
        email : {$regex : "^"+email+"$",$options:"i"}
      }, {_id:1,email:1},(err,result)=>{
        if(err) return next(err);
        
        /** Send error response if email already exists **/
        if(result){
          return res.send({
            status  : API_STATUS_ERROR, 
            message : [{'email':res.__("front.newsletter_subscriber.your_email_id_is_already_exist")}]
          });
        }
        
        const crypto  =   require("crypto");
        let currentTime =   currentTimeStamp();
        let encId   = crypto.createHash("md5").update(currentTime+email).digest("hex");
        
        /** Save newsletter subscribers data **/
        newsletter_subscribers.insertOne({
          email       :   email,
          status      :   ACTIVE,
          user_id     :   DEACTIVE,
          language    :   language,
          enc_id      :   encId,
          is_subscribe:   SUBSCRIBED,
          modified    :   getUtcDate(),
          created     :   getUtcDate()
        },(insertErr,insertResult)=>{
          if(!insertErr){
            /** Send success response **/
            res.send({
              status    : API_STATUS_SUCCESS,
              message   : res.__("front.newsletter_subscriber.subscribe_successfully_message")
            });
          }else{
            /** Send error response **/
            res.send({
              status    : API_STATUS_ERROR,
              message   : res.__("front.something_went_wrong_please_try_again_later")
            });
          }
        });     
      });
    }
  }
}
module.exports = new Home();
