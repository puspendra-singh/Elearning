/** Model file path for current plugin **/
const modelPath     =   __dirname+"/model/questions";
const question      =   require(modelPath);

/** Routing is used to post a question **/
routes.post(API_URL+"post_question",(req,res,next)=>{
    question.postQuestion(req,res,next);
});

/** Routing is used to get related question **/
routes.post(API_URL+"related_question",(req,res,next)=>{
    question.relatedQuestion(req,res,next);
});

/** Routing is used to get all related question **/
routes.post(API_URL+"related_question_list",(req,res,next)=>{
    question.relatedQuestionList(req,res,next);
});