const { ObjectId } = require("mongodb");


function Questions(req, res) {

	/** Function is used to post a question**/
  	this.postQuestion   = (req, res, next)=> {
		req.body       	= sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
	    let userId   	= (req.body.user_id) 		? req.body.user_id : '';
	    let private   	= (req.body.private) 		? req.body.private : '';
	    let question   	= (req.body.question) 		? req.body.question : '';
	    let plagiarism  = (req.body.plagiarism) 	? req.body.plagiarism : '';
	    let category    = (req.body.category) 		? req.body.category : [];
      	let subCategory = (req.body.sub_category) 	? req.body.sub_category : [];

	    /** Check body */
	    req.checkBody({	
	    	"private" :{
		        notEmpty		:true,
		        errorMessage	:res.__("front.question.please_select_question_type")
		    },
		    "question" :{
		        notEmpty		:true,
		        errorMessage	:res.__("front.question.please_enter_question")
		    },  
	    	"plagiarism" :{
		        notEmpty		:true,
		        errorMessage	:res.__("front.question.please_select_plagiarism")
		    }, 
		    "category" :{
		        notEmpty		:true,
		        errorMessage	:res.__("front.question.please_select_category")
		    }, 
	        "sub_category":{
	        	notEmpty		:true,
	        	errorMessage	:res.__("front.question.please_select_subcategory")
	        },
	    });

	    let errors  = parseValidationFront(req.validationErrors());
	    errors      = (errors && Object.keys(errors).length>0) ? errors :  {};
	    if(errors && Object.keys(errors).length == NOT){
		    category 		= arrayToObject(category);
	      	subCategory 	= arrayToObject(subCategory);
	      	let insertData	= {
	      		student_id      : ObjectId(userId),
	      		category 		: category,
	      		private 		: private,
	      		question 		: question,
	      		plagiarism 		: plagiarism,
	      		sub_category 	: subCategory,
	      		is_answer       : DEACTIVE,
	      		created         : getUtcDate()
	      	}

	      	/** Insert question data **/
	      	let collection	=	db.collection('posted_questions');
			collection.insertOne(insertData, (error,result)=>{
		      	if(error) return next();

		      	/*** return success */ 
				return res.send({
			        status		:	API_STATUS_SUCCESS,
			        message		:	res.__("front.question.question_has_been_posted_successfully"),
			        result    	: 	'',
			        error		:	{},
			    });
			})
		}else{
			/*** return Error */ 
			res.send({
		        status	:	API_STATUS_ERROR,
		        error	:	errors,
		        result  : '',
		        message : ''
		    });
		}
  	} //End postQuestion


  	/** Function is used to related question **/
  	this.relatedQuestion= (req, res, next)=> {
  		req.body       	= sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
	    let userId   	= (req.body.user_id) 		? req.body.user_id : '';
	    let question   	= (req.body.question) 		? req.body.question : '';
	    let category   	= (req.body.category) 		? req.body.category : [];
	    let subCategory = (req.body.sub_category) 	? req.body.sub_category : [];
	    let languageId  = (req.body.language_id) 	? req.body.language_id : '';
	   	category 		= arrayToObject(category);
	    subCategory 	= arrayToObject(subCategory);

	    /** Search Questions**/
  		let collection	=	db.collection('posted_questions');
      	collection.find(
      		{
      			'$or'  : [ 
      				{ user_id : ObjectId(userId) }, 
      				{ user_id : {'$ne': ObjectId(userId)}, private: false } 
      			],
      			'$and' : [ 
      				{
      					is_answer 	: ACTIVE, 
      					question 	: new RegExp(question, "i"), 
      					category 	: {$in: category}, 
      					sub_category: {$in : subCategory} 
      				} 
      			]
      		},
      		{	
      			'$projection':{
      				question : 1,
      				answer   : 1
      			}
      		}
      	).toArray((error, result) => {
      		if(error) return next();

	        /*** return success */ 
			return res.send({
		        status		:	API_STATUS_SUCCESS,
		        message		:	'',
		        result    	: 	(result) ? [{id : '', question: '', answer :''}] : [],
		        error		:	{},
		    });
      	}); 
  	}// End relatedQuestion

  	/** Function is used to get all related question **/
  	this.relatedQuestionList= (req, res, next)=> {
  		req.body       	= sanitizeData(req.body, NOT_ALLOWED_TAGS_XSS);
	    let userId   	= (req.body.user_id) 		? req.body.user_id : '';
	    let question   	= (req.body.question) 		? req.body.question : '';
	    let category   	= (req.body.category) 		? req.body.category : [];
	    let subCategory = (req.body.sub_category) 	? req.body.sub_category : [];
	    let languageId  = (req.body.language_id) 	? req.body.language_id : '';
	   	category 		= arrayToObject(category);
	    subCategory 	= arrayToObject(subCategory);

	    /** Search Questions**/
  		let collection	=	db.collection('posted_questions');
      	collection.find(
      		{
      			'$or'  : [ 
      				{ user_id : ObjectId(userId) }, 
      				{ user_id : {'$ne': ObjectId(userId)}, private: false } 
      			],
      			'$and' : [ 
      				{
      					is_answer 	: ACTIVE, 
      					question 	: new RegExp(question, "i"), 
      					category 	: {$in: category}, 
      					sub_category: {$in : subCategory} 
      				} 
      			]
      		},
      		{	
      			'$projection':{
      				question : 1,
      				answer   : 1
      			}
      		}
      	).toArray((error, result) => {
      		if(error) return next();

	        /*** return success */ 
			return res.send({
		        status		:	API_STATUS_SUCCESS,
		        message		:	'',
		        result    	: 	(result) ? result : [],
		        error		:	{},
		    });
      	}); 
  	}// End relatedQuestionList
}
module.exports = new Questions();
