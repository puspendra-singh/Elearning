const { ObjectId } = require("mongodb");
function Plans(req, res) {

  	/** Function is used to get student plans **/
  	this.list  = (req, res, next)=> {
	    let languageId = (req.body.language_id) ? req.body.language_id : DEFAULT_LANGUAGE_MONGO_ID;
	    let userId     = (req.body.user_id)  ? req.body.user_id : '';

	    /** Get plan list **/
	    const collection = db.collection("subscription_plans");
	    collection.aggregate([
	        {$match : {
	          is_active : ACTIVE
	        }},
	        {$project:{
	           access_library :1,no_of_question:1,slug:1, price: 1,validity:1,
	           title : "$plan_descriptions."+languageId+".title",product:1,
	           description : "$plan_descriptions."+languageId+".description",
			   is_recommend : 1
	         }},
	    ]).toArray((err, result)=>{
	    	if(err) return next(err)
	    		
	      	/** return success */
	      	return res.send({
		        status    : API_STATUS_SUCCESS,
		        message   : '',
		        result    : (result && result.length > NOT)? result : [],
		        error     : ''
	      	});
	    })
    }// End list

    /** Function is used to get plan detail **/
  	this.getPlanDetail  = (req, res, next)=> {
	    let languageId = (req.body.language_id) ? req.body.language_id : DEFAULT_LANGUAGE_MONGO_ID;
	    let userId     = (req.body.user_id)  ? req.body.user_id : '';
		let planId     = (req.body.plan_id)  ? req.body.plan_id : '';	

		/*** Invalid request */
	    if(!planId) return res.send({
	      status	: API_STATUS_ERROR,
	      message	: res.__("front.user.invalid_request"),
	      result   	: {},
	      error		: [],
	    });


	    /** Get plan list **/
	    const collection = db.collection("subscription_plans");
	    collection.aggregate([
	        {$match : {
	        	_id : ObjectId(planId),
	          	is_active : ACTIVE
	        }},
	        {$project:{
	           access_library :1,no_of_question:1,slug:1, price: 1,validity:1,
	           title : "$plan_descriptions."+languageId+".title",product:1,
	           description : "$plan_descriptions."+languageId+".description",
			   is_recommend :1
	         }},
	    ]).toArray((err, result)=>{
	    	if(err) return next(err)
	    		
	      	/** return success */
	      	return res.send({
		        status    : API_STATUS_SUCCESS,
		        message   : '',
		        result    : (result && result.length > NOT)? result[0] : {},
		        error     : ''
	      	});
	    })
    }// End getPlanDetail


    /** Function is used to subscribe a plan **/
  	this.planSubscription  = async(req, res, next)=> {
  		let productId      = (req.body.product)   ? req.body.product : '';
  		let customerId     = (req.body.customer)  ? req.body.customer : '';
  		let sourceId       = (req.body.source)    ? req.body.source : '';
  		let userId         = (req.body.user_id)   ? req.body.user_id : '';

  		/*** Invalid request */
	    if(!productId || !customerId || !sourceId) return res.send({
			status	:	API_STATUS_ERROR,
			message	:	res.__("front.user.invalid_request"),
			result  : 	{},
			error	:	[],
	    });

	    const stripe = require('stripe')(res.locals.settings["Stripe.key"]);

	    /*** Create card **/
		stripe.customers.createSource(customerId,{source: sourceId}).then(cardResponse=>{

			/*** Create a plan **/
			let planData = {
				amount		: 1500,
			  	currency	: 'inr',
			  	interval	: 'month',
			  	product     : productId,
			}
			stripe.plans.create(planData).then(planResponse=>{

				/*** Create a subscription **/
				let subscriptionData = {
				  	items                  : [{price: (planResponse.id) ? planResponse.id : ''}],
				  	customer               : customerId,
				  	default_payment_method : sourceId
				}
				stripe.subscriptions.create(subscriptionData).then(subscriptionResponse=>{

					/*** Insert record into payment **/
					subscriptionResponse['user_id'] = ObjectId(userId);
					const collection = db.collection("payment");
					collection.insertOne(subscriptionResponse,async (error,result)=>{
						/** return success */
				      	return res.send({
					        status    : API_STATUS_SUCCESS,
					        message   : res.__("front.plan.subscription_has_been_completed"),
					        result    : '',
					        error     : ''
				      	});
			    	});
				}).catch((error)=>{
					
					/** return success */
			      	return res.send({
				        status    : API_STATUS_ERROR,
				       	message   : (error.raw) ? error.raw.message : res.__("front.something_went_wrong_please_try_again_later"),
				        result    : '',
				        error     : ''
			      	});	
				});
			}).catch((error)=>{

				/** return success */
		      	return res.send({
			        status    : API_STATUS_ERROR,
			        message   : (error.raw) ? error.raw.message : res.__("front.something_went_wrong_please_try_again_later"),
			        result    : '',
			        error     : ''
		      	});
		    });	
		}).catch((error)=>{

			/** return error */
	      	return res.send({
		        status    : API_STATUS_ERROR,
		        message   : (error.raw) ? error.raw.message : res.__("front.something_went_wrong_please_try_again_later"),
		        result    : '',
		        error     : ''
	      	});
		});
  	} //End planSubscription

}
module.exports = new Plans();