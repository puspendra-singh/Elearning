/** Model file path for current plugin **/
const modelPath     =	__dirname+"/model/plans";
const plans	        =   require(modelPath);

/** Routing is used to get subscription plans **/
routes.post(API_URL+"plans",(req,res,next)=>{
    plans.list(req,res,next);
});

/** Routing is used to get subscription plan detail **/
routes.post(API_URL+"get_plan_detail",(req,res,next)=>{
    plans.getPlanDetail(req,res,next);
});

/** Routing is used to get subscription plans **/
routes.post(API_URL+"plan_subscription",(req,res,next)=>{
    plans.planSubscription(req,res,next);
});

